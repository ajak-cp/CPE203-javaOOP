public interface Animated{
    int getAnimationPeriod();
    void nextImage();
}
