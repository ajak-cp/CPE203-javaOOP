enum ActionKind
{
   ACTIVITY,
   ANIMATION
}
